#ifndef CONJUNTO_H
#define CONJUNTO_H

#include <iostream>
using namespace std;

#include <string.h>

const int MAX = 20;

enum Mensaje{overflow, ok, yaExiste};

class Conjunto
{
    int elementos[MAX];
    int nelem;
   // int pos;

public:
    Conjunto();
    ~Conjunto() {cout<<"\nENTRA EL DESTRUCTOR";}
        //vaciar
    inline void vacio(){nelem = 0;} //METODO inline
    Mensaje agregarElemento(int);
    bool pertenece(const int);
    void borrarElemento(int n);
};

#endif // CONJUNTO_H
