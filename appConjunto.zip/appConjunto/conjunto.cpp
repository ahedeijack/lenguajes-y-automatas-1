#include "conjunto.h"

Conjunto::Conjunto()
{

}

Mensaje Conjunto::agregarElemento(int n)
/* 0. Excede el tamaño
 *  1. Si se puede agregar
 *  2. Valor duplicado*/
{
    /*if (nelem < MAX){
        for (int i = 0; i < nelem ; i++){
            if(elementos[i] == n ){
                return yaExiste;
            }
            else{
                elementos[nelem] = n;
                nelem++;
                return ok;
            }
        }
    }
    else {
        return overflow;
    }*/
    if(pertenece(n)){
        return yaExiste;
    }
    if(nelem<MAX){
        elementos[nelem++]=n;
        return ok;
    }
    return overflow;
}

bool Conjunto::pertenece(const int n)
{
    for(int i = 0; i < nelem; i++){
        if( elementos[i] == n){
            return true;
            //pos = i;
        }
        else
            return false;
    }
}

void Conjunto::borrarElemento(int n)
{
    /*if(pertenece(n)){
        for(int i = 0; i < nelem; i++){
            if (elementos[i] == n){
                pos = i;
            }
            if( pos != 0){
                elementos[pos] = elementos[pos+1];
            }
        }
        nelem--;
    }*/

    for(int i = 0; i < nelem ; i++){
        if (elementos[i] == n){
            for ( ; i < nelem-1 ; i++)
                elementos[i] = elementos[i+1];
            --nelem;
        }
    }




}
