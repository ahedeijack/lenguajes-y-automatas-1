/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appbusacardatoenarreglo;

/**
 *
 * @author ivan
 */
public class Busquedas {
    
    public static void SecuencialDatosNoOrdenados(int []vec, int X, Numero pos)
                                                //PARA MANEJAR LA REFERENCIA
                                                //Y TENER VARIABLE DE ENTRADA
    {
        pos.valor = -1;
        int i = 0;
        //ENCONTRAR LA PRIMER OCURRENCIA DEL DA6O A BUSCAR
        while(pos.valor == -1 && i < vec.length)
        {
            if(vec[i] == X)
            {
                pos.valor = i;
            }
            i++;
        }
        
        
        //return pos;
    }
                        //LOS DATOS LLEGAN ORDENADOS
    public static void SecuencialDatosOrdenados(int []vec, int X, Numero pos)
    {
        //int pos = -1;
        
        //return pos;
        pos.valor = -1;
        int i = 0;
        while(vec[i] < X)
            i++;
        if(vec[i] == X)
            pos.valor = i;
        
    }
        
    }

