#include "convertidornumericodialogo.h"

ConvertidorNumericoDialogo::ConvertidorNumericoDialogo(QObject *parent) : QObject(parent)
{

}
