#ifndef CONVERTIDORNUMERICODIALOGO_H
#define CONVERTIDORNUMERICODIALOGO_H

#include <QObject>
#include <QDialog>
class ConvertidorNumericoDialogo : public QObject
{
    Q_OBJECT
public:
    explicit ConvertidorNumericoDialogo(QObject *parent = nullptr);

signals:

};

#endif // CONVERTIDORNUMERICODIALOGO_H
